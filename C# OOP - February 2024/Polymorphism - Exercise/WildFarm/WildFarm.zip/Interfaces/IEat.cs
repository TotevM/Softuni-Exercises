﻿using WildFarm.Models;

namespace WildFarm.Interfaces;

public interface IEat
{
    void Eat(Food food);
}
